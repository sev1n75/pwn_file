#!/bin/sh

supervisord -c /super.conf;
sleep infinity;